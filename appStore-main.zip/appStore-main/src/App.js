import AppStore from './components/AppStore'

import './App.css'

const App = () => <AppStore />

export default App
